
document.getElementById("form-builder").onclick = window.open('http://www.google.com', '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');
// // document.getElementById("form-manager").onclick = window.open('formbuilder.html','popUpWindow','height=400,width=600,left=10,top=10,,scrollbars=yes,menubar=no');
